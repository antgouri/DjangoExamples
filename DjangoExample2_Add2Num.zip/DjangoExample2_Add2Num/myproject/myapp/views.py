#from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from django.http import HttpResponse

def add(request):
    if request.method == 'POST':
        num1 = int(request.POST['num1'])
        num2 = int(request.POST['num2'])
        result = num1 + num2
        return HttpResponse(f'The sum is {result}')
    return render(request, 'add.html')

